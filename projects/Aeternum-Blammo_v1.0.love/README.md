Aeternum Blammo
===============

Controls
--------
Right Mouse Button - Shoot To Cursor  
Left Mouse Button - Move To Cursor  
1 - Switch To Missiles  
2 - Switch To Mines  
f11 - Fullscreen  
esc - Quit  

Screenshot
----------
<img src="https://github.com/josefnpat/Aeternum-Blammo/raw/master/assets/screenshot.png" />

Credit
------
Original Source and Inspiration Credit:  
http://love2d.org/forums/viewtopic.php?f=5&t=3633

Music Credits:  
Future, and It Doesn't Work - Starscream  
8BP099 - Released by 8bitpeoples, http://8bitpeoples.com

Font Credits:  
http://www.dafont.com/linesquare-rounded-extended.font
